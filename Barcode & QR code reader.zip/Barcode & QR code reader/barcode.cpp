#include<iostream>
#include<conio.h>
#include<fstream>
#include<vector>
#include<bits/stdc++.h>
#include<string>

using namespace std;

int main()
{
        int qr,qrv;
        fstream file;
        vector<string> row;
        string temp,line,word;
        cout<<"enter qr:";
        cin>>qr;
        file.open("E:/qr.csv",ios::in);
        while(file>>temp)
        {
                row.clear();
                getline(file,line);
                stringstream s(line);

                while(getline(s,word,','))
                {
                        row.push_back(word);
                }
                //stringstream i(row[0]);
                //qrv=0;
                //i>>qrv;
                qrv=stoi(row[0]);
        }
        if(qrv==qr)
        {
                cout<<"details of barcode"<<row[0]<<":\n";
                cout<<"company:"<<row[1];
                cout<<"type:"<<row[2];
                cout<<"price"<<row[3];
        }
        getch();
        return 0;
}
